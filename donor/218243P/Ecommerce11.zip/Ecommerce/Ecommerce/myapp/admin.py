from django.contrib import admin
from myapp.models import Product,Cart,Buy
# Register your models here.
admin.site.register(Product)
admin.site.register(Cart)
admin.site.register(Buy)